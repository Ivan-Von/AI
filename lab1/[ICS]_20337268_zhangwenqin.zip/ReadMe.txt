City.py ：类模块
Function.py ：函数模块
edition1.py ：按要求简化成模块后的代码
edition_all.py ：未简化的代码
diary.txt ：日志