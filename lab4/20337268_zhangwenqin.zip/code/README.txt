SA.py:模拟退火算法
reversi.py：主函数
alpha_beta.py：A-B剪枝算法
evaluation.py：估值函数
new_board.py：更新棋盘