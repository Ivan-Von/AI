TF_IDF.py ：TF_IDF函数
NB.py ： 朴素贝叶斯模型，里面有伯努利模型和多项式模型
KNN_classification.py ：普通KNN模型，欧氏距离加One-hot矩阵
KNN_regression.py ：KNN回归算法