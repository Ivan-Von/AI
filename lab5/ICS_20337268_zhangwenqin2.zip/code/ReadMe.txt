TA好，这是更新后的文件，多加了Jaccard相似度代码
TF_IDF.py ：TF_IDF函数
NB.py ： 朴素贝叶斯模型，里面有伯努利模型和多项式模型
KNN_classification.py ：普通KNN模型，欧氏距离加One-hot矩阵
KNN_regression.py ：KNN回归算法
my_KNN.py : 在写KNN算法时做的所有尝试的合集，三种距离的尝试
有四个代码写出来正确率一致，老人地铁手机.jpg，我都要怀疑我是不是在一图多用造假了